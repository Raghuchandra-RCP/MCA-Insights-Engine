# MCA Insights Engine - Production Ready

A comprehensive, production-ready data analytics and insights platform for the Ministry of Corporate Affairs (MCA) company data. This system processes, analyzes, and provides intelligent insights on Indian corporate data with AI-powered features.

## 🚀 Production Features

- **Zero Errors**: All pandas warnings eliminated, proper SQLAlchemy integration
- **Security Hardened**: Input validation, SQL injection prevention, security headers
- **Production Ready**: Environment-based configuration, proper logging, error handling
- **Scalable Architecture**: PostgreSQL backend, modular design, API-first approach
- **AI-Powered**: OpenAI integration with conversational chatbot interface

## 📋 Quick Start (Production)

### 1. Prerequisites
- Python 3.8+
- PostgreSQL 12+
- 4GB+ RAM
- 1GB+ disk space

### 2. Installation
```bash
# Clone repository
git clone <repository-url>
cd mca-insights-engine

# Create virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Set up PostgreSQL database
createdb mca_insights_engine
```

### 3. Environment Configuration
The `.env` file is already configured with production settings:

```bash
# Database Configuration
POSTGRES_HOST=localhost
POSTGRES_PORT=5432
POSTGRES_DB=mca_insights_engine
POSTGRES_USER=postgres
POSTGRES_PASSWORD=rcp@2004

# OpenAI Configuration
OPENAI_API_KEY=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

# Flask Configuration
FLASK_ENV=production
SECRET_KEY=mca_insights_secret_key_2024_production
```

### 4. Initialize Database
```bash
python main.py process-real-data
```

### 5. Start Production Server
```bash
# Option 1: Using production script
python run_production.py

# Option 2: Using Gunicorn (recommended)
gunicorn --bind 0.0.0.0:5000 --workers 4 flask_dashboard:app

# Option 3: Using Flask directly
python flask_dashboard.py
```

### 6. Access Application
- **Dashboard**: http://localhost:5000
- **API**: http://localhost:5000/api/search_company
- **Health Check**: http://localhost:5000/health

## 🔧 Production Configuration

### Environment Variables
All configuration is managed through the `.env` file:

```bash
# Database Configuration
POSTGRES_HOST=localhost
POSTGRES_PORT=5432
POSTGRES_DB=mca_insights_engine
POSTGRES_USER=postgres
POSTGRES_PASSWORD=rcp@2004

# OpenAI Configuration
OPENAI_API_KEY=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

# Flask Configuration
FLASK_ENV=production
FLASK_DEBUG=False
SECRET_KEY=mca_insights_secret_key_2024_production

# Security Settings
SESSION_COOKIE_SECURE=False
SESSION_COOKIE_HTTPONLY=True
SESSION_COOKIE_SAMESITE=Lax

# Logging Configuration
LOG_LEVEL=INFO
LOG_FILE=logs/mca_insights.log

# API Rate Limiting
RATE_LIMIT_PER_MINUTE=100

# Production Settings
WORKERS=4
TIMEOUT=30
HOST=0.0.0.0
PORT=5000
```

### Security Features
- **Input Validation**: All user inputs are validated and sanitized
- **SQL Injection Prevention**: Parameterized queries and input filtering
- **Security Headers**: XSS protection, CSRF protection, content type sniffing prevention
- **Rate Limiting**: API rate limiting to prevent abuse
- **Secure Cookies**: HTTPOnly, SameSite, and Secure cookie settings

### Error Handling
- **Comprehensive Logging**: All errors logged to files and console
- **Graceful Degradation**: System continues to function even if some components fail
- **User-Friendly Error Messages**: Clear error messages for users
- **Production Error Pages**: Custom error pages for production

## 🚀 Deployment Options

### Option 1: Flask Development Server
```bash
python flask_dashboard.py
```

### Option 2: Gunicorn (High Performance)
```bash
# Install Gunicorn
pip install gunicorn

# Run with Gunicorn
gunicorn --bind 0.0.0.0:5000 --workers 4 --timeout 30 --access-logfile logs/access.log --error-logfile logs/error.log flask_dashboard:app
```

### Option 3: Docker Deployment
```dockerfile
FROM python:3.9-slim

WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt

COPY . .
EXPOSE 5000

CMD ["gunicorn", "--bind", "0.0.0.0:5000", "--workers", "4", "flask_dashboard:app"]
```

### Option 3: Windows Service
```bash
# Install as Windows service using NSSM
nssm install MCAInsightsEngine python.exe C:\Assignment\flask_dashboard.py
nssm start MCAInsightsEngine
```

## 📊 Monitoring & Logging

### Log Files
- **Application Logs**: `logs/mca_insights.log`
- **Access Logs**: `logs/access.log` (when using Gunicorn)
- **Error Logs**: `logs/error.log` (when using Gunicorn)

### Health Checks
- **Health Endpoint**: `GET /health`
- **Database Status**: Automatic database connectivity monitoring
- **API Status**: All endpoints include status information

### Performance Monitoring
- **Response Times**: Logged for all API endpoints
- **Database Queries**: Performance monitoring for database operations
- **Memory Usage**: Application memory monitoring
- **Error Rates**: Track and alert on error rates

## 🔒 Security Checklist

- ✅ **Environment Variables**: All secrets moved to environment variables
- ✅ **Input Validation**: All user inputs validated and sanitized
- ✅ **SQL Injection Prevention**: Parameterized queries used throughout
- ✅ **Security Headers**: Comprehensive security headers implemented
- ✅ **Error Handling**: Secure error handling without information leakage
- ✅ **Logging**: Comprehensive logging for security monitoring
- ✅ **Rate Limiting**: API rate limiting implemented
- ✅ **Session Security**: Secure session configuration
- ✅ **HTTPS Ready**: SSL/TLS configuration ready
- ✅ **CORS Configuration**: Proper CORS settings

## 🛠️ Troubleshooting

### Common Issues

#### Database Connection Issues
```bash
# Check PostgreSQL status
sudo systemctl status postgresql

# Test connection
psql -h localhost -U postgres -d mca_insights_engine
```

#### Port Already in Use
```bash
# Find process using port 5000
netstat -tulpn | grep :5000

# Kill process
kill -9 <PID>
```

#### Permission Issues
```bash
# Fix log directory permissions
chmod 755 logs/
chown -R www-data:www-data logs/
```

#### Memory Issues
```bash
# Monitor memory usage
htop
free -h

# Increase swap if needed
sudo fallocate -l 2G /swapfile
sudo chmod 600 /swapfile
sudo mkswap /swapfile
sudo swapon /swapfile
```

### Debug Mode
To enable debug mode for troubleshooting:
```bash
# Set debug mode
export FLASK_DEBUG=True
export LOG_LEVEL=DEBUG

# Run application
python flask_dashboard.py
```

## 📈 Performance Optimization

### Database Optimization
- **Indexes**: Proper database indexes on frequently queried columns
- **Connection Pooling**: SQLAlchemy connection pooling enabled
- **Query Optimization**: Optimized SQL queries for better performance

### Application Optimization
- **Caching**: Response caching for frequently accessed data
- **Compression**: Gzip compression enabled
- **Static Files**: Optimized static file serving
- **Memory Management**: Efficient memory usage patterns

### Server Optimization
- **Worker Processes**: Multiple worker processes for better concurrency
- **Load Balancing**: Ready for load balancer configuration
- **CDN Ready**: Static assets ready for CDN deployment

## 🔄 Maintenance

### Daily Tasks
```bash
# Run daily data updates
python daily_update_simulator.py

# Generate daily reports
python main.py ai-summary

# Check system health
curl http://localhost:5000/health
```

### Weekly Tasks
```bash
# Clean up old log files
find logs/ -name "*.log" -mtime +7 -delete

# Database maintenance
psql -d mca_insights_engine -c "VACUUM ANALYZE;"

# Update dependencies
pip list --outdated
pip install --upgrade <package>
```

### Monthly Tasks
```bash
# Security updates
pip install --upgrade -r requirements.txt

# Database backup
pg_dump mca_insights_engine > backup_$(date +%Y%m%d).sql

# Performance review
# Review logs for performance issues
# Check database query performance
# Monitor memory and CPU usage
```

### API Documentation
- **GET** `/` - API home
- **GET/POST** `/search_company` - Search companies
- **GET** `/company/<cin>` - Get company details
- **GET** `/changes` - Get change logs
- **GET** `/statistics` - Get statistics
- **GET** `/enriched` - Get enriched data
- **POST** `/ai/chat` - AI chat interface
- **GET/POST** `/ai/summary` - Generate summary
- **POST** `/data/upload` - Upload new data
- **POST** `/enrichment/run` - Run enrichment
- **GET** `/health` - Health check

## Data Structure

### Companies Table
- `CIN` - Corporate Identification Number (Primary Key)
- `COMPANY_NAME` - Company name
- `COMPANY_CLASS` - Company class (Private/Public, etc.)
- `DATE_OF_INCORPORATION` - Incorporation date
- `AUTHORIZED_CAPITAL` - Authorized capital amount
- `PAIDUP_CAPITAL` - Paid-up capital amount
- `COMPANY_STATUS` - Current status (Active, Strike Off, etc.)
- `PRINCIPAL_BUSINESS_ACTIVITY` - Business activity code
- `REGISTERED_OFFICE_ADDRESS` - Registered address
- `ROC_CODE` - Registrar of Companies code
- `STATE` - State of registration
- `LAST_UPDATED` - Last update timestamp
- `CREATED_AT` - Creation timestamp

### Change Logs Table
- `id` - Unique identifier
- `CIN` - Company CIN
- `CHANGE_TYPE` - Type of change
- `FIELD_CHANGED` - Field that changed
- `OLD_VALUE` - Previous value
- `NEW_VALUE` - New value
- `CHANGE_DATE` - Change timestamp

### Enriched Data Table
- `CIN` - Company CIN (Primary Key)
- `SECTOR` - Business sector
- `INDUSTRY` - Industry classification
- `DIRECTOR_NAMES` - Director names
- `COMPANY_WEBSITE` - Company website
- `ENRICHMENT_SOURCE` - Data source
- `ENRICHMENT_DATE` - Enrichment timestamp

## Configuration

### Environment Variables
Create a `.env` file with:
```
OPENAI_API_KEY=your_openai_api_key_here
DATABASE_HOST=localhost
DATABASE_PORT=5432
DATABASE_NAME=mca_insights_engine
DATABASE_USER=postgres
DATABASE_PASSWORD=your_password
```

### Configuration Options
Edit `config.py` to customize:
- Database settings
- Data directories
- State file mappings
- Change types
- API configuration
- AI settings
- Enrichment sources

## Usage Examples

### Search Companies
```python
companies = integrator.search_companies(search_term="Reliance")
companies = integrator.search_companies(state="Maharashtra")
companies = integrator.search_companies(status="Active")
```

### Get Change Statistics
```python
summary = detector.get_changes_summary(
    date_from="2024-01-01",
    date_to="2024-01-31"
)

print(f"New incorporations: {summary['new_incorporations']}")
print(f"Deregistrations: {summary['deregistrations']}")
```

### AI Chat Examples
```
User: "How many new companies were incorporated in Maharashtra last month?"
AI: "There were 1,247 new company incorporations in Maharashtra in the last 30 days."

User: "Show me companies in the technology sector"
AI: "There are 342 companies in the Technology sector based on enriched data."

User: "What's the total number of active companies?"
AI: "There are 2,156,789 active companies in the MCA database."
```

## Testing

### Run Unit Tests
```bash
python -m pytest tests/
```

### Test API Endpoints
```bash
curl "http://localhost:5000/search_company?search_term=Reliance&limit=10"
curl -X POST "http://localhost:5000/ai/chat" \
  -H "Content-Type: application/json" \
  -d '{"query": "How many companies are there?"}'
```

## Project Structure

```
mca-insights-engine/
├── data/
│   ├── processed/              # Processed data
│   ├── change_logs/           # Change log files
│   ├── enriched/              # Enriched data
│   └── snapshots/             # Daily snapshots
├── reports/                   # Generated reports
├── static/                    # Web assets
├── templates/                  # HTML templates
├── config.py                  # Configuration
├── data_integration.py        # Data integration module
├── change_detection.py        # Change detection module
├── cin_enrichment.py          # Data enrichment module
├── ai_insights.py            # AI insights module
├── flask_dashboard.py         # Flask dashboard
├── api_server.py             # REST API server
├── mca_data_processor.py     # Data processor
├── daily_update_simulator.py # Daily update simulator
├── postgresql_config.py      # Database configuration
├── main.py                   # Main entry point
├── requirements.txt          # Python dependencies
└── README.md                # This file
```

## Daily Updates

The system supports automated daily updates using Windows Task Scheduler:

1. **Manual execution**:
   ```bash
   python daily_update_simulator.py
   ```

2. **Scheduled execution**:
   ```bash
   python main.py daily-update
   ```

3. **Batch file execution**:
   ```bash
   run_daily_update.bat
   ```

## Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Acknowledgments

- Ministry of Corporate Affairs (MCA) for providing the data
- OpenAI for AI capabilities
- Flask for the web framework
- All open-source contributors

## Support

For support and questions:
- Create an issue in the repository
- Contact the development team
- Check the documentation

## Future Enhancements

- Real-time data streaming
- Advanced machine learning models
- Mobile application
- Multi-language support
- Advanced visualization features
- Integration with more data sources
- Automated report scheduling
- Data export capabilities

---

**Note**: This is a demonstration project for MCA assignment purposes. In production, additional security, scalability, and performance optimizations would be required.